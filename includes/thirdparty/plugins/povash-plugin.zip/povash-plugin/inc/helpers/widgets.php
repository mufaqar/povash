<?php
///----Blog widgets---
///----footer widgets---
//About Company
class Povash_Sidebar_Menu extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Povash_Sidebar_Menu', /* Name */esc_html__('Povash Sidebar Menu','povash'), array( 'description' => esc_html__('Show the Sidebar Menu', 'povash' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		
		echo wp_kses_post($before_widget);?>
      		
		

<div class="sidebar-widget categories-widget">
                                <ul class="listx clearfix navigation">
                                     <?php wp_nav_menu( array( 'theme_location' => 'sidebar_menu', 'container_id' => 'navbar-collapse-1',
											'container_class'=>'navbar-collapse collapse navbar-right',
											'menu_class'=>'nav navbar-nav',
											'fallback_cb'=>false, 
											'items_wrap' => '%3$s', 
											'container'=>false,
											'depth'=>'3',
											'walker'=> new Bootstrap_walker()  
										) ); ?>  
                                </ul>
                            </div>
            
        <?php
		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;

		$instance['content'] = $new_instance['content'];	
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{

		$content = ($instance) ? esc_attr($instance['content']) : '';
		?>
        
   
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('content')); ?>"><?php esc_html_e('Content:', 'povash'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('content')); ?>" name="<?php echo esc_attr($this->get_field_name('content')); ?>" ><?php echo wp_kses_post($content); ?></textarea>
        </p>
       
		<?php 
	}
	
}
//Popular Post 
class Povash_Popular_Post extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Povash_Popular_Post', /* Name */esc_html__('Povash Popular Post','povash'), array( 'description' => esc_html__('Show the Popular Post', 'povash' )) );
	}
 

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget); ?>
		
        <!--Popular Posts-->
        <div class="widget_popular_post">
            <?php echo wp_kses_post($before_title.$title.$after_title); ?>
			
			<?php $query_string = 'posts_per_page='.$instance['number'];
				if( $instance['cat'] ) $query_string .= '&cat='.$instance['cat'];
				 
				$this->posts($query_string);
			?>
        </div>
        
		<?php echo wp_kses_post($after_widget);
	}
 
 
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ( $instance ) ? esc_attr($instance['title']) : esc_html__('Popular Post', 'povash');
		$number = ( $instance ) ? esc_attr($instance['number']) : 3;
		$cat = ( $instance ) ? esc_attr($instance['cat']) : '';?>
			
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'povash'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('No. of Posts:', 'povash'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
        </p>
       
    	<p>
            <label for="<?php echo esc_attr($this->get_field_id('categories')); ?>"><?php esc_html_e('Category', 'povash'); ?></label>
            <?php wp_dropdown_categories( array('show_option_all'=>esc_html__('All Categories', 'povash'), 'selected'=>$cat, 'class'=>'widefat', 'name'=>$this->get_field_name('categories')) ); ?>
        </p>
            
		<?php 
	}
	
	function posts($query_string)
	{
		
		$query = new WP_Query($query_string);
		if( $query->have_posts() ):?>
        
           	<!-- Title -->
			<?php 
				global $post;
				while( $query->have_posts() ): $query->the_post(); 
				$post_thumbnail_id = get_post_thumbnail_id($post->ID);
				$post_thumbnail_url = wp_get_attachment_url($post_thumbnail_id);
			?>
            <article class="post">
                <figure class="post-thumb" >  <?php the_post_thumbnail('povash_85x75', array('class' => 'lazy-image owl-lazy')); ?> </figure>
                <h5><a href="<?php echo esc_url(get_the_permalink(get_the_id()));?>"><?php the_title(); ?></a></h5>
                <div class="post-info"><?php echo get_the_date();?></div>
            </article>
            <?php endwhile; ?>
            
        <?php endif;
		wp_reset_postdata();
    }
}

//Our Project
class Povash_Our_Projects extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Povash_Our_Projects', /* Name */esc_html__('Povash Our Projects','povash'), array( 'description' => esc_html__('Show the Our Projects', 'povash' )) );
	}
 
	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget); ?>
		
        <!-- Instagram Widget -->
        <div class="instagram-widget">
            <?php echo wp_kses_post($before_title.$title.$after_title); ?>
            <div class="inner-box">
                <div class="wrapper-box">
                    <?php 
						$args = array('post_type' => 'povash_project', 'showposts'=>$instance['number']);
						if( $instance['cat'] ) $args['tax_query'] = array(array('taxonomy' => 'project_cat','field' => 'id','terms' => (array)$instance['cat']));
						 
						$this->posts($args);
					?>
                </div><!-- /.gallery-wrapper -->
            </div>
        </div>
        
        <?php echo wp_kses_post($after_widget);
	}
 
 
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		
		return $instance;
	}
	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ($instance) ? esc_attr($instance['title']) : 'Our Projects';
		$number = ( $instance ) ? esc_attr($instance['number']) : 6;
		$cat = ( $instance ) ? esc_attr($instance['cat']) : '';?>
		
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('Our Projects', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('Number of posts: ', 'povash'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('cat')); ?>"><?php esc_html_e('Category', 'povash'); ?></label>
            <?php wp_dropdown_categories( array('show_option_all'=>esc_html__('All Categories', 'povash'), 'selected'=>$cat, 'taxonomy' => 'project_cat', 'class'=>'widefat', 'name'=>$this->get_field_name('cat')) ); ?>
        </p>
            
		<?php 
	}
	
	function posts($args)
	{
		
		$query = new WP_Query($args);
		if( $query->have_posts() ):?>
        
           	<!-- Title -->
            <?php 
				while( $query->have_posts() ): $query->the_post(); 
				global $post; 
				$post_thumbnail_id = get_post_thumbnail_id($post->ID);
				$post_thumbnail_url = wp_get_attachment_url($post_thumbnail_id);
			?>
            <div class="image">
                <?php the_post_thumbnail('povash_85x75', array('class' => 'lazy-image owl-lazy')); ?>
                <div class="overlay-link"><a href="<?php echo esc_url($post_thumbnail_url);?>" class="lightbox-image" data-fancybox="gallery"><span class="fa fa-plus"></span></a></div>
            </div>
            <?php endwhile; ?>
                
        <?php endif;
		wp_reset_postdata();
    }
}

//Subscribe Form
class Povash_Subscribe_Form extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Povash_Subscribe_Form', /* Name */esc_html__('Povash Subscribe Form','povash'), array( 'description' => esc_html__('Show the Subscribe Form', 'povash' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget);?>
      		
            <!-- Newsletter Widget -->
            <div class="widget_newsletter">
                <?php echo wp_kses_post($before_title.$title.$after_title); ?>
                <div class="widget-content">
                    <form action="http://feedburner.google.com/fb/a/mailverify" accept-charset="utf-8">
                        <div class="form-group">
                            <i class="flaticon-mail"></i>
                            <input type="hidden" id="uri7" name="uri" value="<?php echo wp_kses_post($instance['id']); ?>">
                            <input type="text" placeholder="<?php esc_html_e('Email Address...', 'povash'); ?>">
                            <button type="submit" class="theme-btn"><span class="flaticon-right"></span></button>
                        </div>
                    </form>
                    <h5><?php echo wp_kses_post($instance['content']); ?></h5>
                </div>
            </div>
            
		<?php
		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;

		$instance['title'] = strip_tags($new_instance['title']);
		$instance['id'] = $new_instance['id'];
		$instance['content'] = $new_instance['content'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ($instance) ? esc_attr($instance['title']) : 'Don’t miss anything keep update.';
		$id = ($instance) ? esc_attr($instance['id']) : '';
		$content = ($instance) ? esc_attr($instance['content']) : '';
		
		?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'povash'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('Title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" ><?php echo wp_kses_post($title); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('id')); ?>"><?php esc_html_e('Enter FeedBurner ID:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('themeforest', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('id')); ?>" name="<?php echo esc_attr($this->get_field_name('id')); ?>" type="text" value="<?php echo esc_attr($id); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('content')); ?>"><?php esc_html_e('Content:', 'povash'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('content')); ?>" name="<?php echo esc_attr($this->get_field_name('content')); ?>" ><?php echo wp_kses_post($content); ?></textarea>
        </p>   
                
		<?php 
	}
	
}


///----footer widgets---
//About Company
class Povash_About_Company extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Povash_About_Company', /* Name */esc_html__('Povash About Company','povash'), array( 'description' => esc_html__('Show the About Company', 'povash' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		
		echo wp_kses_post($before_widget);?>
      		
			<!--Footer Column-->
            <div class="logo-widget">
                <div class="widget-content">
                    <div class="footer-logo">
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img class="lazy-image" src="<?php echo esc_url($instance['widget_logo_img']); ?>" data-src="<?php echo esc_url($instance['widget_logo_img']); ?>" alt="<?php esc_attr_e('Awesome Image', 'povash'); ?>" /></a>
                    </div>
                    <h3><?php echo wp_kses_post($instance['content']); ?> </h3>
                    <div class="link-btn"><a href="<?php echo esc_url($instance['btn_link']); ?>" class="theme-btn"><i class="flaticon-right"></i><?php echo wp_kses_post($instance['btn_title']); ?></a></div>
                </div>
            </div>
            
        <?php
		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;

		$instance['widget_logo_img'] = $new_instance['widget_logo_img'];
		$instance['content'] = $new_instance['content'];
		$instance['btn_title'] = $new_instance['btn_title'];
		$instance['btn_link'] = $new_instance['btn_link'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$widget_logo_img = ($instance) ? esc_attr($instance['widget_logo_img']) : 'http://el.commonsupport.com/newwp/povash/wp-content/uploads/2020/06/logo-2.png';
		$content = ($instance) ? esc_attr($instance['content']) : '';
		$btn_title = ($instance) ? esc_attr($instance['btn_title']) : '';
		$btn_link = ($instance) ? esc_attr($instance['btn_link']) : '';
		?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('widget_logo_img')); ?>"><?php esc_html_e('Logo Image Url:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('Image Url', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('widget_logo_img')); ?>" name="<?php echo esc_attr($this->get_field_name('widget_logo_img')); ?>" type="text" value="<?php echo esc_attr($widget_logo_img); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('content')); ?>"><?php esc_html_e('Content:', 'povash'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('content')); ?>" name="<?php echo esc_attr($this->get_field_name('content')); ?>" ><?php echo wp_kses_post($content); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('btn_title')); ?>"><?php esc_html_e('Button Title:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('Experts advice', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('btn_title')); ?>" name="<?php echo esc_attr($this->get_field_name('btn_title')); ?>" type="text" value="<?php echo esc_attr($btn_title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('btn_link')); ?>"><?php esc_html_e('Enter Button Link:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('#', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('btn_link')); ?>" name="<?php echo esc_attr($this->get_field_name('btn_link')); ?>" type="text" value="<?php echo esc_attr($btn_link); ?>" />
        </p>
               
                
		<?php 
	}
	
}

//Our Project 2
class Povash_Our_Projects_Two extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Povash_Our_Projects_Two', /* Name */esc_html__('Povash Footer Projects','povash'), array( 'description' => esc_html__('Show the Footer Projects', 'povash' )) );
	}
 
	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget); ?>
		
        <!-- Instagram Widget -->
        <div class="column">
            <?php echo wp_kses_post($before_title.$title.$after_title); ?>
            <div class="instagram-widget">
                <div class="inner-box">
                    <div class="wrapper-box">
                        <?php 
							$args = array('post_type' => 'povash_project', 'showposts'=>$instance['number']);
							if( $instance['cat'] ) $args['tax_query'] = array(array('taxonomy' => 'project_cat','field' => 'id','terms' => (array)$instance['cat']));
							 
							$this->posts($args);
						?>
                    </div><!-- /.gallery-wrapper -->
                </div>
            </div>
        </div>
        
        <?php echo wp_kses_post($after_widget);
	}
 
 
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		
		return $instance;
	}
	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ($instance) ? esc_attr($instance['title']) : 'Projects';
		$number = ( $instance ) ? esc_attr($instance['number']) : 6;
		$cat = ( $instance ) ? esc_attr($instance['cat']) : '';?>
		
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('Our Projects', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('Number of posts: ', 'povash'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('cat')); ?>"><?php esc_html_e('Category', 'povash'); ?></label>
            <?php wp_dropdown_categories( array('show_option_all'=>esc_html__('All Categories', 'povash'), 'selected'=>$cat, 'taxonomy' => 'project_cat', 'class'=>'widefat', 'name'=>$this->get_field_name('cat')) ); ?>
        </p>
            
		<?php 
	}
	
	function posts($args)
	{
		
		$query = new WP_Query($args);
		if( $query->have_posts() ):?>
        
           	<!-- Title -->
            <?php 
				while( $query->have_posts() ): $query->the_post(); 
				global $post; 
				$post_thumbnail_id = get_post_thumbnail_id($post->ID);
				$post_thumbnail_url = wp_get_attachment_url($post_thumbnail_id);
			?>
            <div class="image">
                <?php the_post_thumbnail('povash_85x75', array('class' => 'lazy-image owl-lazy')); ?>
                <div class="overlay-link"><a href="<?php echo esc_url($post_thumbnail_url);?>" class="lightbox-image" data-fancybox="gallery"><span class="fa fa-plus"></span></a></div>
            </div>
            <?php endwhile; ?>
                
        <?php endif;
		wp_reset_postdata();
    }
}


///----footer Two widgets---
//Trending Post 
class Povash_Trending_Post extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Povash_Trending_Post', /* Name */esc_html__('Povash Trending Post','povash'), array( 'description' => esc_html__('Show the Trending Post', 'povash' )) );
	}
 

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget); ?>
		
        
        <!-- Trending Posts -->
        <div class="post-widget">
            <?php echo wp_kses_post($before_title.$title.$after_title); ?>
            <div class="widget-content">
                <?php $query_string = 'posts_per_page='.$instance['number'];
					if( $instance['cat'] ) $query_string .= '&cat='.$instance['cat'];
					 
					$this->posts($query_string);
				?>
            </div>  
        </div>
        
		<?php echo wp_kses_post($after_widget);
	}
 
 
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ( $instance ) ? esc_attr($instance['title']) : esc_html__('Trending Post', 'povash');
		$number = ( $instance ) ? esc_attr($instance['number']) : 2;
		$cat = ( $instance ) ? esc_attr($instance['cat']) : '';?>
			
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'povash'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('No. of Posts:', 'povash'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
        </p>
       
    	<p>
            <label for="<?php echo esc_attr($this->get_field_id('categories')); ?>"><?php esc_html_e('Category', 'povash'); ?></label>
            <?php wp_dropdown_categories( array('show_option_all'=>esc_html__('All Categories', 'povash'), 'selected'=>$cat, 'class'=>'widefat', 'name'=>$this->get_field_name('categories')) ); ?>
        </p>
            
		<?php 
	}
	
	function posts($query_string)
	{
		
		$query = new WP_Query($query_string);
		if( $query->have_posts() ):?>
        
           	<!-- Title -->
			<?php 
				global $post;
				while( $query->have_posts() ): $query->the_post(); 
				$post_thumbnail_id = get_post_thumbnail_id($post->ID);
				$post_thumbnail_url = wp_get_attachment_url($post_thumbnail_id);
			?>
            <div class="post">
                <div class="image"><?php the_post_thumbnail('povash_85x75', array('class' => 'lazy-image owl-lazy')); ?> </div>
                <div class="date"><?php echo get_the_date();?></div>
                <h4><a href="<?php echo esc_url(get_the_permalink(get_the_id()));?>"><?php the_title(); ?></a></h4>
            </div>
            <?php endwhile; ?>
            
        <?php endif;
		wp_reset_postdata();
    }
}

//Contact Details
class Povash_Contact_Details extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Povash_Contact_Details', /* Name */esc_html__('Povash Contact Details','povash'), array( 'description' => esc_html__('Show the Contact Details', 'povash' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget);?>
      		
			<!--Footer Column-->
            <div class="contact-widget">
                <?php echo wp_kses_post($before_title.$title.$after_title); ?>
                <div class="widget-content">
                    <div class="text"><?php echo wp_kses_post($instance['address']); ?></div>
                    <ul class="list">
                        <li><?php esc_html_e('Call Us :', 'povash'); ?>  <a href="tel:<?php echo esc_url($instance['phone_no']); ?>"><?php echo wp_kses_post($instance['phone_no']); ?></a></li>
                        <li><?php esc_html_e('Mail us :', 'povash'); ?>  <a href="mailto:<?php echo esc_url($instance['email_address']); ?>"><?php echo wp_kses_post($instance['email_address']); ?></a></li>
                    </ul>
                    <?php if( $instance['show'] ): ?>
                    <ul class="social-links clearfix">
                        <?php echo wp_kses_post(povash_get_social_icons()); ?>
                    </ul>
                    <?php endif; ?>
                </div> 
            </div>
           
        <?php
		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;

		$instance['title'] = strip_tags($new_instance['title']);
		$instance['address'] = $new_instance['address'];
		$instance['phone_no'] = $new_instance['phone_no'];
		$instance['email_address'] = $new_instance['email_address'];
		$instance['show'] = $new_instance['show'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ($instance) ? esc_attr($instance['title']) : 'Contact Details';
		$address = ($instance) ? esc_attr($instance['address']) : '';
		$phone_no = ($instance) ? esc_attr($instance['phone_no']) : '';
		$email_address = ($instance) ? esc_attr($instance['email_address']) : '';
		$show = ($instance) ? esc_attr($instance['show']) : '';
		?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Enter Title:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('Contact Details', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('address')); ?>"><?php esc_html_e('Address:', 'povash'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('address')); ?>" name="<?php echo esc_attr($this->get_field_name('address')); ?>" ><?php echo wp_kses_post($address); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('phone_no')); ?>"><?php esc_html_e('Phone Number:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('+1 800 555 44 00', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('phone_no')); ?>" name="<?php echo esc_attr($this->get_field_name('phone_no')); ?>" type="text" value="<?php echo esc_attr($phone_no); ?>" />
        </p> 
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('email_address')); ?>"><?php esc_html_e('Email Addess:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('supportteam@info.com', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('email_address')); ?>" name="<?php echo esc_attr($this->get_field_name('email_address')); ?>" type="text" value="<?php echo esc_attr($email_address); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('show')); ?>"><?php esc_html_e('Show Social Icons:', 'povash'); ?></label>
			<?php $selected = ( $show ) ? ' checked="checked"' : ''; ?>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('show')); ?>"<?php echo esc_attr($selected); ?> name="<?php echo esc_attr($this->get_field_name('show')); ?>" type="checkbox" value="true" />
        </p>
               
		<?php 
	}
	
}


///----footer Three widgets---
//About Company Two
class Povash_About_Company_Two extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Povash_About_Company_Two', /* Name */esc_html__('Povash About Company Two','povash'), array( 'description' => esc_html__('Show the About Company Two', 'povash' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget);?>
      		
			<!--Footer Column-->
            <div class="about-widget">
                <?php echo wp_kses_post($before_title.$title.$after_title); ?>
                <div class="widget-content">
                    <div class="text"><?php echo wp_kses_post($instance['content']); ?></div>
                    <ul class="list">
                        <?php echo wp_kses_post($instance['widget_feature_list']); ?>
                    </ul>
                    <div class="image"><img src="<?php echo esc_url($instance['widget_certificate_img']); ?>" alt="<?php esc_attr_e('Awesome Image', 'povash'); ?>"></div>
                </div>
            </div>
            
        <?php
		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;

		$instance['title'] = strip_tags($new_instance['title']);
		$instance['content'] = $new_instance['content'];
		$instance['widget_feature_list'] = $new_instance['widget_feature_list'];
		$instance['widget_certificate_img'] = $new_instance['widget_certificate_img'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ($instance) ? esc_attr($instance['title']) : 'About Company';
		$content = ($instance) ? esc_attr($instance['content']) : '';
		$widget_feature_list = ($instance) ? esc_attr($instance['widget_feature_list']) : '';
		$widget_certificate_img = ($instance) ? esc_attr($instance['widget_certificate_img']) : 'http://el.commonsupport.com/newwp/povash/wp-content/uploads/2020/06/certificate.png';
		
		?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Enter Title:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('About Company', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('content')); ?>"><?php esc_html_e('Content:', 'povash'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('content')); ?>" name="<?php echo esc_attr($this->get_field_name('content')); ?>" ><?php echo wp_kses_post($content); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('widget_feature_list')); ?>"><?php esc_html_e('Feature List:', 'povash'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('widget_feature_list')); ?>" name="<?php echo esc_attr($this->get_field_name('widget_feature_list')); ?>" ><?php echo wp_kses_post($widget_feature_list); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('widget_certificate_img')); ?>"><?php esc_html_e('Certificate Image Url:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('Image Url', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('widget_certificate_img')); ?>" name="<?php echo esc_attr($this->get_field_name('widget_certificate_img')); ?>" type="text" value="<?php echo esc_attr($widget_certificate_img); ?>" />
        </p>
               
                
		<?php 
	}
	
}

//Recent Post 
class Povash_Recent_Post extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Povash_Recent_Post', /* Name */esc_html__('Povash Recent Post','povash'), array( 'description' => esc_html__('Show the Recent Post', 'povash' )) );
	}
 

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget); ?>
		
        
        <!-- Trending Posts -->
        <div class="post-widget">
            <?php echo wp_kses_post($before_title.$title.$after_title); ?>
            <div class="widget-content">
                <?php $query_string = 'posts_per_page='.$instance['number'];
					if( $instance['cat'] ) $query_string .= '&cat='.$instance['cat'];
					 
					$this->posts($query_string);
				?>
                <a href="<?php echo esc_url($instance['btn_link']); ?>" class="read-more-post"><?php echo wp_kses_post($instance['btn_title']); ?> <i class="flaticon-right"></i></a>
            </div>  
        </div>
        
		<?php echo wp_kses_post($after_widget);
	}
 
 
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		$instance['btn_title'] = $new_instance['btn_title'];
		$instance['btn_link'] = $new_instance['btn_link'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ( $instance ) ? esc_attr($instance['title']) : esc_html__('Recent Post', 'povash');
		$number = ( $instance ) ? esc_attr($instance['number']) : 2;
		$cat = ( $instance ) ? esc_attr($instance['cat']) : '';
		$btn_title = ( $instance ) ? esc_attr($instance['btn_title']) : 'Read More from Blog';
		$btn_link = ( $instance ) ? esc_attr($instance['btn_link']) : '#';
		?>
			
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'povash'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('No. of Posts:', 'povash'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
        </p>
       
    	<p>
            <label for="<?php echo esc_attr($this->get_field_id('categories')); ?>"><?php esc_html_e('Category', 'povash'); ?></label>
            <?php wp_dropdown_categories( array('show_option_all'=>esc_html__('All Categories', 'povash'), 'selected'=>$cat, 'class'=>'widefat', 'name'=>$this->get_field_name('categories')) ); ?>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('btn_title')); ?>"><?php esc_html_e('Button Title: ', 'povash'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('btn_title')); ?>" name="<?php echo esc_attr($this->get_field_name('btn_title')); ?>" type="text" value="<?php echo esc_attr( $btn_title ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('btn_link')); ?>"><?php esc_html_e('Button Link: ', 'povash'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('btn_link')); ?>" name="<?php echo esc_attr($this->get_field_name('btn_link')); ?>" type="text" value="<?php echo esc_attr( $btn_link ); ?>" />
        </p>
            
		<?php 
	}
	
	function posts($query_string)
	{
		
		$query = new WP_Query($query_string);
		if( $query->have_posts() ):?>
        
           	<!-- Title -->
			<?php 
				global $post;
				while( $query->have_posts() ): $query->the_post(); 
				$post_thumbnail_id = get_post_thumbnail_id($post->ID);
				$post_thumbnail_url = wp_get_attachment_url($post_thumbnail_id);
			?>
            <div class="post">
                <div class="image" style="background-image:url(<?php echo esc_url($post_thumbnail_url);?>);"></div>
                <div class="date"><?php echo get_the_date();?></div>
                <h4><a href="<?php echo esc_url(get_the_permalink(get_the_id()));?>"><?php the_title(); ?> </a></h4>
            </div>
            <?php endwhile; ?>
            
        <?php endif;
		wp_reset_postdata();
    }
}


///----footer Four widgets---
//About Company Three
class Povash_About_Company_Three extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Povash_About_Company_Three', /* Name */esc_html__('Povash About Company Three','povash'), array( 'description' => esc_html__('Show the About Company Three', 'povash' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		//$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget);?>
      		
			<!--Footer Column-->
            <div class="about-widget-two">
                <div class="footer-logo">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img class="lazy-image" src="<?php echo esc_url($instance['widget_logo_img2']); ?>" data-src="<?php echo esc_url($instance['widget_logo_img2']); ?>" alt="<?php esc_attr_e('Awesome Image', 'povash'); ?>" /></a>
                </div>
                <div class="widget-content">
                    <div class="text"><?php echo wp_kses_post($instance['content']); ?></div>
                    <?php if( $instance['show'] ): ?>
                    <ul class="social-links clearfix">
                        <?php echo wp_kses_post(povash_get_social_icons()); ?>
                    </ul>
                    <?php endif; ?>
                    <div class="copyright-text"><?php echo wp_kses_post($instance['copyright']); ?></div>
                </div>
            </div>
            
        <?php
		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;

		$instance['widget_logo_img2'] = $new_instance['widget_logo_img2'];
		$instance['content'] = $new_instance['content'];
		$instance['show'] = $new_instance['show'];
		$instance['copyright'] = $new_instance['copyright'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$widget_logo_img2 = ($instance) ? esc_attr($instance['widget_logo_img2']) : 'http://el.commonsupport.com/newwp/povash/wp-content/uploads/2020/06/logo-v4-2.png';
		$content = ($instance) ? esc_attr($instance['content']) : '';
		$show = ( $instance ) ? esc_attr($instance['show']) : '';
		$copyright = ( $instance ) ? esc_attr($instance['copyright']) : '© 2020 Povash consultancy.';
		?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('widget_logo_img2')); ?>"><?php esc_html_e('Logo Image Url:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('Image Url', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('widget_logo_img2')); ?>" name="<?php echo esc_attr($this->get_field_name('widget_logo_img2')); ?>" type="text" value="<?php echo esc_attr($widget_logo_img2); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('content')); ?>"><?php esc_html_e('Content:', 'povash'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('content')); ?>" name="<?php echo esc_attr($this->get_field_name('content')); ?>" ><?php echo wp_kses_post($content); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('show')); ?>"><?php esc_html_e('Show Social Icons:', 'povash'); ?></label>
			<?php $selected = ( $show ) ? ' checked="checked"' : ''; ?>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('show')); ?>"<?php echo esc_attr($selected); ?> name="<?php echo esc_attr($this->get_field_name('show')); ?>" type="checkbox" value="true" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('copyright')); ?>"><?php esc_html_e('Copyright:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('Enter Copyright Text', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('copyright')); ?>" name="<?php echo esc_attr($this->get_field_name('copyright')); ?>" type="text" value="<?php echo esc_attr($copyright); ?>" />
        </p>
               
                
		<?php 
	}
	
}


///----footer Five widgets---
//About Company Four
class Povash_About_Company_Four extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Povash_About_Company_Four', /* Name */esc_html__('Povash About Company Four','povash'), array( 'description' => esc_html__('Show the About Company Four', 'povash' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		
		echo wp_kses_post($before_widget);?>
      		
			<!--Footer Column-->
            <div class="logo-widget">
                <div class="widget-content">
                    <div class="footer-logo">
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img class="lazy-image" src="<?php echo esc_url($instance['widget_logo_img3']); ?>" data-src="<?php echo esc_url($instance['widget_logo_img3']); ?>" alt="<?php esc_attr_e('Awesome Image', 'povash'); ?>" /></a>
                    </div>
                    <div class="text"><?php echo wp_kses_post($instance['content']); ?></div>
                    <div class="link-btn"><a href="<?php echo esc_url($instance['btn_link']); ?>" class="theme-btn"><?php echo wp_kses_post($instance['btn_title']); ?> <i class="fa fa-caret-right"></i></a></div>
                </div>
            </div>
            
        <?php
		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;

		$instance['widget_logo_img3'] = $new_instance['widget_logo_img3'];
		$instance['content'] = $new_instance['content'];
		$instance['btn_title'] = $new_instance['btn_title'];
		$instance['btn_link'] = $new_instance['btn_link'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$widget_logo_img3 = ($instance) ? esc_attr($instance['widget_logo_img3']) : 'http://el.commonsupport.com/newwp/povash/wp-content/uploads/2020/06/logo-v5-2.png';
		$content = ($instance) ? esc_attr($instance['content']) : '';
		$btn_title = ($instance) ? esc_attr($instance['btn_title']) : '';
		$btn_link = ($instance) ? esc_attr($instance['btn_link']) : '';
		?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('widget_logo_img3')); ?>"><?php esc_html_e('Logo Image Url:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('Image Url', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('widget_logo_img3')); ?>" name="<?php echo esc_attr($this->get_field_name('widget_logo_img3')); ?>" type="text" value="<?php echo esc_attr($widget_logo_img3); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('content')); ?>"><?php esc_html_e('Content:', 'povash'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('content')); ?>" name="<?php echo esc_attr($this->get_field_name('content')); ?>" ><?php echo wp_kses_post($content); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('btn_title')); ?>"><?php esc_html_e('Button Title:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('Experts advice', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('btn_title')); ?>" name="<?php echo esc_attr($this->get_field_name('btn_title')); ?>" type="text" value="<?php echo esc_attr($btn_title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('btn_link')); ?>"><?php esc_html_e('Enter Button Link:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('#', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('btn_link')); ?>" name="<?php echo esc_attr($this->get_field_name('btn_link')); ?>" type="text" value="<?php echo esc_attr($btn_link); ?>" />
        </p>
               
                
		<?php 
	}
	
}

//Subscribe Form Two
class Povash_Subscribe_Form_Two extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Povash_Subscribe_Form_Two', /* Name */esc_html__('Povash Subscribe Form Two','povash'), array( 'description' => esc_html__('Show the Subscribe Form Two', 'povash' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget);?>
      		
			<!--Footer Column-->
            <div class="column">
                <?php echo wp_kses_post($before_title.$title.$after_title); ?>
                <div class="subscribe-widget">
                    <div class="text"><?php echo wp_kses_post($instance['content']); ?></div>
                    <form action="http://feedburner.google.com/fb/a/mailverify" accept-charset="utf-8" method="post">
                        <div class="form-group">
                            <input type="hidden" id="uri8" name="uri" value="<?php echo wp_kses_post($instance['id']); ?>">
                            <input type="text" placeholder="<?php esc_html_e('Email Address...', 'povash'); ?>">
                            <button type="submit" class="theme-btn"><i class="flaticon-send"></i></button>
                        </div>
                    </form>
                    <?php if( $instance['show'] ): ?>
                    <ul class="social-links clearfix">
                        <?php echo wp_kses_post(povash_get_social_icons()); ?>
                    </ul>
                    <?php endif; ?>
                </div>
            </div>
            
		<?php
		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;

		$instance['title'] = strip_tags($new_instance['title']);
		$instance['content'] = $new_instance['content'];
		$instance['id'] = $new_instance['id'];
		$instance['show'] = $new_instance['show'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ($instance) ? esc_attr($instance['title']) : 'Subscribe';
		$content = ($instance) ? esc_attr($instance['content']) : '';
		$id = ($instance) ? esc_attr($instance['id']) : '';
		$show = ( $instance ) ? esc_attr($instance['show']) : '';
		
		?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Enter Title:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('Subscribe Us', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('content')); ?>"><?php esc_html_e('Content:', 'povash'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('content')); ?>" name="<?php echo esc_attr($this->get_field_name('content')); ?>" ><?php echo wp_kses_post($content); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('id')); ?>"><?php esc_html_e('Enter FeedBurner ID:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('themeforest', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('id')); ?>" name="<?php echo esc_attr($this->get_field_name('id')); ?>" type="text" value="<?php echo esc_attr($id); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('show')); ?>"><?php esc_html_e('Show Social Icons:', 'povash'); ?></label>
			<?php $selected = ( $show ) ? ' checked="checked"' : ''; ?>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('show')); ?>"<?php echo esc_attr($selected); ?> name="<?php echo esc_attr($this->get_field_name('show')); ?>" type="checkbox" value="true" />
        </p>
               
                
		<?php 
	}
	
}


///----Service Sidebar widgets---
//Our Brochures
class Povash_Brochures extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Povash_Brochures', /* Name */esc_html__('Povash Our Brochures','povash'), array( 'description' => esc_html__('Show the info Our Brochures', 'povash' )) );
	}
	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		
		echo wp_kses_post($before_widget);?>
      		
            <!--Start Single sidebar-->
            <div class="widget_brochur" style="background-image: url(<?php echo esc_url($instance['bg_img']); ?>);">
                <div class="widget-content">
                    <div class="icon"><img src="<?php echo esc_url($instance['pdf_icon_img']); ?>" alt="<?php esc_attr_e('Awesome Image', 'povash'); ?>"></div>
                    <h5><?php echo wp_kses_post($instance['pdf_file_subtitle']); ?></h5>
                    <h4><?php echo wp_kses_post($instance['pdf_file_title']); ?></h4>
                    <a href="<?php echo esc_url($instance['pdf_file_link']); ?>"><i class="flaticon-right"></i><?php echo wp_kses_post($instance['pdf_file_size']); ?></a>
                </div>
            </div>
            
		<?php
		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['bg_img'] = $new_instance['bg_img'];
		$instance['pdf_icon_img'] = $new_instance['pdf_icon_img'];
		$instance['pdf_file_subtitle'] = $new_instance['pdf_file_subtitle'];
		$instance['pdf_file_title'] = $new_instance['pdf_file_title'];
		$instance['pdf_file_size'] = $new_instance['pdf_file_size'];
		$instance['pdf_file_link'] = $new_instance['pdf_file_link'];
		
		return $instance;
	}
	/** @see WP_Widget::form */
	function form($instance)
	{
		$bg_img = ($instance) ? esc_attr($instance['bg_img']) : 'http://el.commonsupport.com/newwp/povash/wp-content/uploads/2020/05/bg-27.jpg';
		$pdf_icon_img = ($instance) ? esc_attr($instance['pdf_icon_img']) : 'http://el.commonsupport.com/newwp/povash/wp-content/uploads/2020/05/icon-60.png';
		$pdf_file_subtitle = ($instance) ? esc_attr($instance['pdf_file_subtitle']) : '';
		$pdf_file_title = ($instance) ? esc_attr($instance['pdf_file_title']) : '';
		$pdf_file_size = ($instance) ? esc_attr($instance['pdf_file_size']) : '';
		$pdf_file_link = ($instance) ? esc_attr($instance['pdf_file_link']) : '';
		
		?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('bg_img')); ?>"><?php esc_html_e('background Image Url:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('background Image Url', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('bg_img')); ?>" name="<?php echo esc_attr($this->get_field_name('bg_img')); ?>" type="text" value="<?php echo esc_attr($bg_img); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('pdf_icon_img')); ?>"><?php esc_html_e('PDF Icon Image Url:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('PDF Icon Image Url', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('pdf_icon_img')); ?>" name="<?php echo esc_attr($this->get_field_name('pdf_icon_img')); ?>" type="text" value="<?php echo esc_attr($pdf_icon_img); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('pdf_file_subtitle')); ?>"><?php esc_html_e('PDF Sub Title:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('Case Studies', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('pdf_file_subtitle')); ?>" name="<?php echo esc_attr($this->get_field_name('pdf_file_subtitle')); ?>" type="text" value="<?php echo esc_attr($pdf_file_subtitle); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('pdf_file_title')); ?>"><?php esc_html_e('PDF Title:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('Audit & Assuarance', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('pdf_file_title')); ?>" name="<?php echo esc_attr($this->get_field_name('pdf_file_title')); ?>" type="text" value="<?php echo esc_attr($pdf_file_title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('pdf_file_size')); ?>"><?php esc_html_e('File Size:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('Download (2.5 mb)', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('pdf_file_size')); ?>" name="<?php echo esc_attr($this->get_field_name('pdf_file_size')); ?>" type="text" value="<?php echo esc_attr($pdf_file_size); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('pdf_file_link')); ?>"><?php esc_html_e('PDF Link:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('#', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('pdf_file_link')); ?>" name="<?php echo esc_attr($this->get_field_name('pdf_file_link')); ?>" type="text" value="<?php echo esc_attr($pdf_file_link); ?>" />
        </p>
               
		<?php 
	}
	
}

//Need Help
class Povash_Need_Help extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Povash_Need_Help', /* Name */esc_html__('Povash Need Help','povash'), array( 'description' => esc_html__('Show the Need Help', 'povash' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		
		echo wp_kses_post($before_widget);?>
      		
			<div class="widget_contact" style="background-image: url(<?php echo esc_url($instance['bg_img']); ?>);">
                <div class="widget-content">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/icon-55.png" alt="<?php esc_attr_e('Awesome Image', 'povash'); ?>">
                    <h4><?php echo wp_kses_post($instance['title']); ?></h4>
                    <div class="phone-number"><a href="tel:<?php echo esc_url($instance['phone_no']); ?>"><?php echo wp_kses_post($instance['phone_no']); ?></a></div>
                    <div class="email"><a href="mailto:<?php echo esc_url($instance['email_address']); ?>"><?php echo wp_kses_post($instance['email_address']); ?></a></div>
                    <div class="link-btn"><a href="<?php echo esc_url($instance['btn_link']); ?>" class="theme-btn btn-style-one">
                        <span class="btn-title"><?php echo wp_kses_post($instance['btn_title']); ?></span>
                    </a></div>
                </div>
            </div>
            
        <?php
		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['bg_img'] = strip_tags($new_instance['bg_img']);
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['phone_no'] = $new_instance['phone_no'];
		$instance['email_address'] = $new_instance['email_address'];
		$instance['btn_title'] = $new_instance['btn_title'];
		$instance['btn_link'] = $new_instance['btn_link'];
		
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		
		$bg_img = ($instance) ? esc_attr($instance['bg_img']) : 'http://el.commonsupport.com/newwp/povash/wp-content/uploads/2020/05/bg-25.jpg';
		$title = ($instance) ? esc_attr($instance['title']) : 'Do you need any help?';
		$phone_no = ($instance) ? esc_attr($instance['phone_no']) : '';
		$email_address = ($instance) ? esc_attr($instance['email_address']) : '';
		$btn_title = ($instance) ? esc_attr($instance['btn_title']) : '';
		$btn_link = ($instance) ? esc_attr($instance['btn_link']) : '';
		
		?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('bg_img')); ?>"><?php esc_html_e('background Image Url:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('background Image Url', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('bg_img')); ?>" name="<?php echo esc_attr($this->get_field_name('bg_img')); ?>" type="text" value="<?php echo esc_attr($bg_img); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Enter Title:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('Do you need any help?', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('phone_no')); ?>"><?php esc_html_e('Phone Number:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('+1 800 555 44 678', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('phone_no')); ?>" name="<?php echo esc_attr($this->get_field_name('phone_no')); ?>" type="text" value="<?php echo esc_attr($phone_no); ?>" />
        </p> 
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('email_address')); ?>"><?php esc_html_e('Email Addess:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('info@example.com', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('email_address')); ?>" name="<?php echo esc_attr($this->get_field_name('email_address')); ?>" type="text" value="<?php echo esc_attr($email_address); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('btn_title')); ?>"><?php esc_html_e('Button Title:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('APPOINTMENT', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('btn_title')); ?>" name="<?php echo esc_attr($this->get_field_name('btn_title')); ?>" type="text" value="<?php echo esc_attr($btn_title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('btn_link')); ?>"><?php esc_html_e('Button Link:', 'povash'); ?></label>
            <input placeholder="<?php esc_attr_e('#', 'povash');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('btn_link')); ?>" name="<?php echo esc_attr($this->get_field_name('btn_link')); ?>" type="text" value="<?php echo esc_attr($btn_link); ?>" />
        </p>
               
                
		<?php 
	}
	
}

