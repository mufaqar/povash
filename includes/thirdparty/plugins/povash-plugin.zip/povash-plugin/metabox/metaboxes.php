<?php
if ( ! function_exists( "povash_add_metaboxes" ) ) {
	function povash_add_metaboxes( $metaboxes ) {
		$directories_array = array(
			'page.php',
			'post.php',
			'projects.php',
			'service.php',
			'team.php',
			'testimonials.php',
			'event.php',
            'post.php',
		);
		foreach ( $directories_array as $dir ) {
			$metaboxes[] = require_once( POVASHPLUGIN_PLUGIN_PATH . '/metabox/' . $dir );
		}

		return $metaboxes;
	}

	add_action( "redux/metaboxes/povash_options/boxes", "povash_add_metaboxes" );
}