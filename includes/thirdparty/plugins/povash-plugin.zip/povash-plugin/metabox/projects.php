<?php
return array(
	'title'      => 'Povash Project Setting',
	'id'         => 'povash_meta_projects',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'povash_project' ),
	'sections'   => array(
		array(
			'id'     => 'povash_projects_meta_setting',
			'fields' => array(
				array(
					'id'       => 'icon_image',
					'type'     => 'media',
					'url'      => true,
					'title'    => esc_html__( 'Project Icon Image', 'povash' ),
					'desc'     => esc_html__( 'Insert Project Icon Image URl', 'povash' ),
				),
				array(
					'id'    => 'icon_description',
					'type'  => 'text',
					'title' => esc_html__( 'Enter Icon Description', 'povash' ),
				),
				array(
					'id'    => 'project_link',
					'type'  => 'text',
					'title' => esc_html__( 'Read More Link', 'povash' ),
				),
				array(
					'id'    => 'dimension',
					'type'  => 'select',
					'title' => esc_html__( 'Choose the Extra height', 'povash' ),
					'options'  => array(
						'extra_height' => esc_html__( 'Extra Height', 'povash' ),
						'normal_height' => esc_html__( 'Normal Height', 'povash' ),
					),
					'default'  => 'normal_height',
				),
			),
		),
	),
);