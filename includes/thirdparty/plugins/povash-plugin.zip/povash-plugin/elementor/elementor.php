<?php

namespace POVASHPLUGIN\Element;


class Elementor {
	static $widgets = array(
		'theme_slider',
		'service_icon',
		'about_left',
		'about_right',
		'experience',
		'service_tab',
		'clients',
		'testimonial_left',
		'testimonial_right',
		'funfact',
		'ourmission',
		'gallery',
		'cta',
		'h1_blog_title',
		'h1_blog_left',
		'h1_blog_right',
		'footer_top',
		'footer_widget1',
		'footer_widget2',
		'footer_widget3',
		'footer_bottom',
		'theme_slider2',
		'about_left2',
		'about_right2',
		'service_img',
		'washing_left',
		'washing_right',
		'weprovide_left',
		'weprovide_right',
		'team',
		'testimonials',
		'h2_blog',
		'cta2',
		'about3',
		'about_left4',
		'about_right4',
		'team2',
		'experience_left2',
		'experience_right2',
		'gallery2',
		'wi_menu',
		'wi_help',
		'wi_download',
		'service_details1',
		'service_details2',
		'service_details3',
		'team3',
		'contact_left',
		'weprovide',
		'appoinment',
		'coupons',
		'video3',
		'pricing3',
		'services_price',
		'project_details1',
		'project_details2',
		'project_details3',
		'team_details_left',
		'team_details_right',
		'team_details1',
		'team_details2',
		'team_details3',
		'h4_slider',
		'h4_feature',
		'h4_about_left',
		'h4_about_right',
		'h4_works',
		'h4_chooseus',
		'h4_service_tab',
		'h4_faq_left',
		'h4_faq_right',
		'h4_funfact',
		'h4_testimonial',
		'h4_team',
		'h4_blog',
        'testimonials2',
		'h5_slider',
		'h5_about_left',
		'h5_about_right',
		'h5_service_img',
		'h5_chooseus',
		'h5_cta',
		'h5_working',
		'h5_pricing',
		'h5_testimonial',
		'h5_funfact',
		'h5_team',
		'h5_blog',
		'h6_slider',
		'h6_service_icone',
		'h6_about_left',
		'h6_about_right',
		'h6_chooseus',
		'h6_service_img',
		'h6_contact',
        'project_details_new1',
		'project_details_new2',
		'project_details_new3',
		'faq',
		'pricing_calculator',
        'team_new',
        'team_block',
	);

	static function init() {
		add_action( 'elementor/init', array( __CLASS__, 'loader' ) );
		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'register_cats' ) );
	}

	static function loader() {

		foreach ( self::$widgets as $widget ) {

			$file = POVASHPLUGIN_PLUGIN_PATH . '/elementor/' . $widget . '.php';
			if ( file_exists( $file ) ) {
				require_once $file;
			}

			add_action( 'elementor/widgets/widgets_registered', array( __CLASS__, 'register' ) );
		}
	}

	static function register( $elemntor ) {
		foreach ( self::$widgets as $widget ) {
			$class = '\\POVASHPLUGIN\\Element\\' . ucwords( $widget );

			if ( class_exists( $class ) ) {
				$elemntor->register_widget_type( new $class );
			}
		}
	}

	static function register_cats( $elements_manager ) {

		$elements_manager->add_category(
			'povash',
			[
				'title' => esc_html__( 'Povash', 'povash' ),
				'icon'  => 'fa fa-plug',
			]
		);
		$elements_manager->add_category(
			'templatepath',
			[
				'title' => esc_html__( 'Template Path', 'povash' ),
				'icon'  => 'fa fa-plug',
			]
		);

	}
}

Elementor::init();