<?php

namespace POVASHPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Team_New extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'povash_team_new';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Team New', 'povash' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-briefcase';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'povash' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'team_new',
			[
				'label' => esc_html__( 'Team New', 'povash' ),
			]
		);
		$this->add_control(
            'style', 
				[
					'label'   => esc_html__( 'Choose Different Style', 'callix' ),
					'label_block' => true,
					'type'    => Controls_Manager::SELECT,
					'return_value' => 'style1',
                    'default'      => 'style1',
					'options' => array(
						'style1' => esc_html__( 'Choose Style 1', 'callix' ),
						'style2' => esc_html__( 'Choose Style 2', 'callix' ),
						'style3' => esc_html__( 'Choose Style 3', 'callix' ),
					),
				]
		);
		$this->add_control(
			'bgimg',
			[
				'label' => esc_html__('Background image', 'rashid'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$this->add_control(
			'bgimg1',
			[
				'label' => esc_html__('Background image', 'rashid'),
				'conditions' => array(
					'relation' => 'or',
					'terms'    => array(
						array(
							'name'     => 'style',
							'operator' => '==',
							'value'    => 'style1',
						),
					),
				),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$this->add_control(
			'image',
				[
				  'label' => __( 'Image', 'bitfix' ),
				  'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'style',
								'operator' => '==',
								'value'    => 'style3',
							),
						),
					),
				  'type' => Controls_Manager::MEDIA,
				  'default' => ['url' => Utils::get_placeholder_image_src(),],
				]
		);
		$this->add_control(
			'alt_text',
			[
				'label'       => __( 'Alt text', 'bitfix' ),
				'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'style',
								'operator' => '==',
								'value'    => 'style3',
							),
						),
					),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Description', 'bitfix' ),
			]
		);
		$this->add_control(
			'image1',
				[
				  'label' => __( 'Image', 'bitfix' ),
				  'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'style',
								'operator' => '==',
								'value'    => 'style3',
							),
						),
					),
				  'type' => Controls_Manager::MEDIA,
				  'default' => ['url' => Utils::get_placeholder_image_src(),],
				]
		);
		$this->add_control(
			'alt_text1',
			[
				'label'       => __( 'Alt text', 'bitfix' ),
				'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'style',
								'operator' => '==',
								'value'    => 'style3',
							),
						),
					),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Description', 'bitfix' ),
			]
		);
		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title', 'elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Sub title', 'elementor' ),
				'default'     => __( '', 'elementor' ),
			]
		);
		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your title', 'elementor' ),
				'default'     => __( '', 'elementor' ),
			]
		);
		$this->add_control(
			'text',
			[
				'label'       => __( 'Description Text', 'rashid' ),
				'conditions' => array(
					'relation' => 'or',
					'terms'    => array(
						array(
							'name'     => 'style',
							'operator' => '==',
							'value'    => 'style1',
						),
					),
				),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Description', 'rashid' ),
			]
		);
		$this->add_control(
			'column',
			[
				'label'   => esc_html__( 'Column', 'bitfix' ),
				'conditions' => array(
					'relation' => 'or',
					'terms'    => array(
						array(
							'name'     => 'style',
							'operator' => '==',
							'value'    => 'style3',
						),
					),
				),
				'type'    => Controls_Manager::SELECT,
				'default' => '3',
				'options' => array(
					'12'   => esc_html__( 'One Column', 'bitfix' ),
					'6'   => esc_html__( 'Two Column', 'bitfix' ),
					'4'   => esc_html__( 'Three Column', 'bitfix' ),
					'3'   => esc_html__( 'Four Column', 'bitfix' ),
					'2'   => esc_html__( 'Six Column', 'bitfix' ),
				),
			]
		);
		$this->add_control(
			'sec_class',
			[
				'label'       => __( 'Section Class', 'rashid' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter Section Class', 'rashid' ),
			]
		);


		$this->end_controls_section();
		
		// New Tab#1

		$this->start_controls_section(
					'content_section',
					[
						'label' => __( 'Team Block', 'inovex' ),
						'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
					]
				);
				$this->add_control(
				  'repeat', 
					[
						'type' => Controls_Manager::REPEATER,
						'seperator' => 'before',
						'default' => 
							[
								['block_title' => esc_html__('Projects Completed', 'inovex')],
							],
						'fields' => 
							[
								'block_image' =>
								[
									'name' => 'block_image',
									'label' => __( 'Image', 'inovex' ),
									'type' => Controls_Manager::MEDIA,
									'default' => ['url' => Utils::get_placeholder_image_src(),],
								],
								'block_alt_text' =>
								[
									'name' => 'block_alt_text',
									'label' => esc_html__('Alt Text', 'inovex'),
									'type' => Controls_Manager::TEXTAREA,
									'default' => esc_html__('', 'inovex')
								],
								'block_title' =>
								[
									'name' => 'block_title',
									'label' => esc_html__('Title', 'inovex'),
									'type' => Controls_Manager::TEXTAREA,
									'default' => esc_html__('', 'inovex')
								],
								'block_subtitle' =>
								[
									'name' => 'block_subtitle',
									'label' => esc_html__('Subtitle', 'inovex'),
									'type' => Controls_Manager::TEXTAREA,
									'default' => esc_html__('', 'inovex')
								],
								'block_feature_str' =>
								[
									'name' => 'block_feature_str',
									'label'       => __( 'Features List', 'inovex' ),
									'type'        => Controls_Manager::TEXTAREA,
									'dynamic'     => [
										'active' => true,
									],
									'placeholder' => __( 'Enter your Features List', 'inovex' ),
									'default'     => __( '', 'inovex' ),
								],
							],
						'title_field' => '{{block_title}}',
					 ]
				);
				
				
		$this->end_controls_section();
		
	
	}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		?>
		
<?php
      echo '
     <script>
 jQuery(document).ready(function($) {

//put the js code under this line 

	if ($(".three-item-carousel").length) {
		$(".three-item-carousel").owlCarousel({
			loop:true,
			margin:30,
			nav:true,
			smartSpeed: 1000,
			autoplay: 500,
			responsive:{
				0:{
					items:1
				},
				480:{
					items:1
				},
				600:{
					items:2
				},
				800:{
					items:2
				},
				1024:{
					items:3
				}
			}
		});    		
	}

//put the code above the line 

  });
</script>';


?>

<?php
      echo '
     <script>
 jQuery(document).ready(function($) {

//put the js code under this line 

	if ($(".four-item-carousel").length) {
		$(".four-item-carousel").owlCarousel({
			loop:true,
			margin:30,
			nav:true,
			smartSpeed: 500,
			autoplay: 5000,
			responsive:{
				0:{
					items:1
				},
				600:{
					items:2
				},
				800:{
					items:2
				},
				1024:{
					items:3
				},
				1200:{
					items:4
				}
			}
		});    		
	}

//put the code above the line 

  });
</script>';


?>

		<?php  if ( 'style1' === $settings['style'] ) : ?>

        <!-- team-ex-section -->
        <section class="<?php echo esc_attr($settings['sec_class']);?> team-ex-section bg-color-3">
            <div class="pattern-layer">
				<?php  if ( esc_url($settings['bgimg']['id']) ) : ?>
                <div class="pattern-1" style="background-image: url(<?php echo wp_get_attachment_url($settings['bgimg']['id']);?>);">
				<?php else :?>
				<div class="pattern-1 noimage">
				<?php endif;?>
				</div>
				<?php  if ( esc_url($settings['bgimg1']['id']) ) : ?>
                <div class="pattern-2" style="background-image: url(<?php echo wp_get_attachment_url($settings['bgimg1']['id']);?>);">
				<?php else :?>
				<div class="pattern-2 noimage">
				<?php endif;?>
				</div>
            </div>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-4 col-md-12 col-sm-12 title-column">
						<?php if($settings['title']): ?>
                        <div class="sec-title light">
                            <h4><?php echo $settings['subtitle'];?></h4>
                            <h2><?php echo $settings['title'];?></h2>
                            <p><?php echo $settings['text'];?></p>
                        </div>
						<?php endif; ?>
                    </div>
                    <div class="col-lg-8 col-md-12 col-sm-12 carousel-column">
                        <div class="carousel-content">
                            <div class="three-item-carousel owl-carousel owl-theme owl-dots-none">
							
								<?php foreach($settings['repeat'] as $item):?>
								
                                <div class="team-block-two">
                                    <div class="inner-box">
                                        <figure class="image-box">
											<a href="<?php echo esc_url($item['block_btnlink']['url']);?>">
												<?php if(wp_get_attachment_url($item['block_image']['id'])): ?>
												<img src="<?php echo wp_get_attachment_url($item['block_image']['id']);?>" alt="<?php echo wp_kses($item['block_alt_text'], $allowed_tags);?>">
												<?php else :?>
												<div class="noimage"></div>
												<?php endif;?>
											</a>
										</figure>
                                        <div class="lower-content">
                                            <div class="share-option">
                                                <span class="fas fa-share-alt"></span>
                                                <ul class="share-links clearfix">
												
                                                    <?php $fearures = explode("\n", ($item['block_feature_str']));?>
													<?php foreach($fearures as $feature):?>
													<?php echo wp_kses($feature, true); ?>
													<?php endforeach; ?>
													
                                                </ul>
                                            </div>
                                            <h3><a href="<?php echo esc_url($item['block_btnlink']['url']);?>"><?php echo wp_kses($item['block_title'], $allowed_tags);?></a></h3>
                                            <span class="designation"><?php echo wp_kses($item['block_subtitle'], $allowed_tags);?></span>
                                        </div>
                                    </div>
                                </div>
								
								<?php endforeach; ?>
								
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- team-ex-section end -->
		
		<?php endif;?>
		
		<?php  if ( 'style2' === $settings['style'] ) : ?>
		
        <section class="<?php echo esc_attr($settings['sec_class']);?> team-section bg-color-3">
			<?php  if ( esc_url($settings['bgimg']['id']) ) : ?>  
            <div class="pattern-layer" style="background-image: url(<?php echo wp_get_attachment_url($settings['bgimg']['id']);?>);">
			<?php else :?>	
			<div class="pattern-layer noimage" >
			<?php endif;?>
			</div>
            <div class="auto-container">
				<?php if($settings['title']): ?>
                <div class="sec-title light">
                    <h4><?php echo $settings['subtitle'];?></h4>
                    <h2><?php echo $settings['title'];?></h2>
                </div>
				<?php endif; ?>
                <div class="carousel-content">
                    <div class="four-item-carousel owl-carousel owl-theme owl-nav-none">
					
						<?php foreach($settings['repeat'] as $item):?>
						
                        <div class="team-block-one">
                            <div class="inner-box">
                                <figure class="image-box">
									<?php if(wp_get_attachment_url($item['block_image']['id'])): ?>
									<img src="<?php echo wp_get_attachment_url($item['block_image']['id']);?>" alt="<?php echo wp_kses($item['block_alt_text'], $allowed_tags);?>">
									<?php else :?>
									<div class="noimage"></div>
									<?php endif;?>
								</figure>
                                <div class="lower-content">
                                    <h3><a href="<?php echo esc_url($item['block_btnlink']['url']);?>"><?php echo wp_kses($item['block_title'], $allowed_tags);?></a></h3>
                                    <span class="designation"><?php echo wp_kses($item['block_subtitle'], $allowed_tags);?></span>
									
                                    <ul class="social-links clearfix">
									
                                        <?php $fearures = explode("\n", ($item['block_feature_str']));?>
										<?php foreach($fearures as $feature):?>
										<?php echo wp_kses($feature, true); ?>
										<?php endforeach; ?>
										
                                    </ul>
									
                                </div>
                            </div>
                        </div>
						
						<?php endforeach; ?>
						
                    </div>
                </div>
            </div>
        </section>
		
		<?php endif;?>		
		
		<?php  if ( 'style3' === $settings['style'] ) : ?>
		
        <section class="team__section five <?php echo esc_attr($settings['sec_class']);?>">
            <div class="shape-1">
			<?php  if ( esc_url($settings['image']['id']) ) : ?>   
			<img src="<?php echo wp_get_attachment_url($settings['image']['id']);?>" alt="<?php echo esc_attr($settings['alt_text']);?>"/>
			<?php else :?>
			<div class="noimage"></div>
			<?php endif;?>
			</div>
            <div class="shape-2" data-parallax='{"y": -100}'>
			<?php  if ( esc_url($settings['image1']['id']) ) : ?>   
			<img src="<?php echo wp_get_attachment_url($settings['image1']['id']);?>" alt="<?php echo esc_attr($settings['alt_text1']);?>"/>
			<?php else :?>
			<div class="noimage"></div>
			<?php endif;?>
			</div>
            <div class="auto-container">
				<?php if($settings['title']): ?>
                <div class="sec__title text-center">
                    <div class="sub__title"><?php echo $settings['subtitle'];?></div>
                    <h2><?php echo $settings['title'];?></h2>
                </div>
				<?php endif; ?>
                <div class="row">
				
					<?php foreach($settings['repeat'] as $item):?>
					
                    <div class="col-lg-<?php echo esc_attr($settings['column'], true );?> team__block">
                        <div class="inner-box wow fadeInUp animated animated" data-wow-delay="00ms" data-wow-duration="1500ms">
                            <div class="image">
							
                                <?php if(wp_get_attachment_url($item['block_image']['id'])): ?>
								<img src="<?php echo wp_get_attachment_url($item['block_image']['id']);?>" alt="<?php echo wp_kses($item['block_alt_text'], $allowed_tags);?>">
								<?php else :?>
								<div class="noimage"></div>
								<?php endif;?>
								
                                <ul class="social-links clearfix">
								
                                    <?php $fearures = explode("\n", ($item['block_feature_str']));?>
									<?php foreach($fearures as $feature):?>
									<?php echo wp_kses($feature, true); ?>
									<?php endforeach; ?>
									
                                </ul>
								
                            </div>
                            <div class="content-bottom">
                                <h4><?php echo wp_kses($item['block_title'], $allowed_tags);?></h4>
                                <div class="designation"><?php echo wp_kses($item['block_subtitle'], $allowed_tags);?></div>
                            </div>
                        </div>
                    </div>
					
					<?php endforeach; ?>
					
                </div>
            </div>
        </section>
		
		<?php endif;?>
            
		<?php 
	}

}