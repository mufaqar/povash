<?php
return array(
	'title'      => 'Povash Testimonials Setting',
	'id'         => 'povash_meta_testimonials',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'povash_testimonials' ),
	'sections'   => array(
		array(
			'id'     => 'povash_testimonials_meta_setting',
			'fields' => array(
				array(
					'id'       => 'client_logo_image',
					'type'     => 'media',
					'url'      => true,
					'title'    => esc_html__( 'Client Logo/Icon Image', 'povash' ),
					'desc'     => esc_html__( 'Insert Logo/Icon Image URl', 'povash' ),
				),
				array(
					'id'       => 'client_hover_image',
					'type'     => 'media',
					'url'      => true,
					'title'    => esc_html__( 'Client Icon Hover Image', 'povash' ),
					'desc'     => esc_html__( 'Insert Icon Hover Image URl', 'povash' ),
				),
				array(
					'id'       => 'client_image',
					'type'     => 'media',
					'url'      => true,
					'title'    => esc_html__( 'Client Image', 'povash' ),
					'desc'     => esc_html__( 'Insert Client Image URl', 'povash' ),
				),
				array(
					'id'       => 'signature_img',
					'type'     => 'media',
					'url'      => true,
					'title'    => esc_html__( 'Signature Image', 'povash' ),
					'desc'     => esc_html__( 'Insert Signature Image URl', 'povash' ),
				),
				array(
					'id'       => 'testimonial_icon',
					'type'     => 'select',
					'title'    => esc_html__( 'Testimonials Icons', 'povash' ),
					'options'  => get_fontawesome_icons(),
				),
				array(
					'id'    => 'client_name',
					'type'  => 'text',
					'title' => esc_html__( 'Author Name', 'povash' ),
				),
				array(
					'id'    => 'test_designation',
					'type'  => 'text',
					'title' => esc_html__( 'Author Designation', 'povash' ),
				),
				array(
					'id'    => 'testimonial_rating',
					'type'  => 'select',
					'title' => esc_html__( 'Choose the Client Rating', 'povash' ),
					'options'  => array(
						'1' => '1',
						'2' => '2',
						'3' => '3',
						'4' => '4',
						'5' => '5',
					),
					'default'  => '5',
				),
			),
		),
	),
);