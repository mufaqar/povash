<?php
return array(
	'title'      => 'Povash Setting',
	'id'         => 'povash_meta',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'page', 'post', 'povash_team' ),
	'sections'   => array(
		require_once POVASHPLUGIN_PLUGIN_PATH . '/metabox/header.php',
		require_once POVASHPLUGIN_PLUGIN_PATH . '/metabox/banner.php',
		require_once POVASHPLUGIN_PLUGIN_PATH . '/metabox/sidebar.php',
		require_once POVASHPLUGIN_PLUGIN_PATH . '/metabox/footer.php',
	),
);